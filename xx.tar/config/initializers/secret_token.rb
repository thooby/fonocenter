# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Fonocenter::Application.config.secret_token = 'efd5c220572cdfc1961ff0e04eb37791cb06c0765ab121c5d8085c73a92d3c9a4f30cdb0e4a8fdadcdfe35a406bf7164b91530ef0718042a6f7126735cf84260'
