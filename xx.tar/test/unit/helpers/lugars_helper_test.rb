require 'test_helper'

class LugarsHelperTest < ActionView::TestCase
end
