require 'test_helper'

class LugarTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
